package fr.studioshi.common.game.model;

import java.awt.Graphics;

import fr.studioshi.common.game.entities.VisualEntity;

public abstract class VisualRender implements VisualEntity {

	protected GraphicElement graphicElement;
	
	public GraphicElement getGraphics() {
		return graphicElement;
	}

	public void render(Graphics graphics) {
		graphicElement.render(graphics);
	}

	public void setGraphics(GraphicElement graphics) {
		this.graphicElement = graphics;
	}

}
