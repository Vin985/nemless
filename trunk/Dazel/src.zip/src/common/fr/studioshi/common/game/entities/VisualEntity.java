package fr.studioshi.common.game.entities;

import java.awt.Graphics;

public interface VisualEntity {

	public void render(Graphics graphics);

}
