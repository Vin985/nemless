package fr.studioshi.common.game.model;

import fr.studioshi.common.game.entities.VisualEntity;

public abstract class GraphicElement implements VisualEntity {
	protected Coordinates coords;

	public GraphicElement() {
	}

	public GraphicElement(Coordinates coords) {
		super();
		this.coords = coords;
	}

	public Coordinates getCoords() {
		return coords;
	}

	public void setCoords(Coordinates coords) {
		this.coords = coords;
	}

}
