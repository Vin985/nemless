package fr.studioshi.common.game.model;

import fr.studioshi.common.game.entities.SoundEntity;

public abstract class SoundRender implements SoundEntity {

	
}
