package fr.studioshi.common.game.entities;

public interface SoundEntity {

	public void playSound();
	
}
