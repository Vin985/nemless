package fr.studioshi.common.game.entities;

public interface GameEntity {
	public void process();
}
