package fr.studioshi.common.game.entities;


public interface GameObjects extends GameEntity, VisualEntity {

}
