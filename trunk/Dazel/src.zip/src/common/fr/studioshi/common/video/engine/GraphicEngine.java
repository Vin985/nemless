package fr.studioshi.common.video.engine;

import fr.studioshi.common.game.entities.VisualEntity;

public interface GraphicEngine extends VisualEntity {

	public void init();
	
	public void destroy();
	
	
}
