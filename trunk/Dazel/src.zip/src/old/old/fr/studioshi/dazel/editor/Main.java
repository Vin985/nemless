/*
 * Created on 2 juil. 2004
 */
 
package old.fr.studioshi.dazel.editor;

/**
 * @author Endy
 */
public class Main
{
	public static void main(String[] args)
	{
		Splashscreen sp = new Splashscreen();
		Fenetre fenetre = new Fenetre();

	}
}
