/*
 * Created on 2 juil. 2004
 */
 
package old.fr.studioshi.dazel.editor;

import javax.swing.JFrame;

/**
 * @author Endy
 */
public class Splashscreen extends JFrame
{
	public Splashscreen()
	{
	}
}       
	