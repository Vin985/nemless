package fr.studioshi.dazel.game.ui.keylisteners;

import java.awt.event.KeyEvent;

import fr.studioshi.common.game.ui.keylistener.KeyHandler;

public class DazelKeyHandler extends KeyHandler {

	public void keyPressed(KeyEvent e) {
	}

	public void keyReleased(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			events.setKeyDownPressed(true);
		}
		if (e.getKeyCode() == KeyEvent.VK_UP) {
			events.setKeyUpPressed(true);
		}
		if (e.getKeyCode() == KeyEvent.VK_ENTER) {
			events.setKeyEnterPressed(true);
		}

	}

	public void keyTyped(KeyEvent e) {
	}

}
