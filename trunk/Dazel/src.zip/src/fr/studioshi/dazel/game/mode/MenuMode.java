package fr.studioshi.dazel.game.mode;

import fr.studioshi.common.game.Game;
import fr.studioshi.common.game.mode.GameMode;
import fr.studioshi.dazel.game.ui.gui.DazelGUIPool;
import fr.studioshi.dazel.game.ui.keylisteners.DazelKeyHandler;
import fr.studioshi.dazel.game.util.DazelConstants;

public class MenuMode extends GameMode {

	public MenuMode(Game game) {
		setGameMode(DazelConstants.MODE_MAIN_MENU);
		setGui(DazelGUIPool.getInstance()
				.getGUI(DazelConstants.MODE_MAIN_MENU, game));
		setKeyListener(new DazelKeyHandler());
	}

}
