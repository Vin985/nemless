package fr.studioshi.dazel.game.util;

public class StringPool {

	private StringPool() {
	}

	public static final String SLASH = "/";

}
