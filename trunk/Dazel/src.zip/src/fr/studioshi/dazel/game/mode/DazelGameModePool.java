package fr.studioshi.dazel.game.mode;

import fr.studioshi.common.game.Game;
import fr.studioshi.common.game.mode.GameMode;
import fr.studioshi.common.game.mode.GameModePool;
import fr.studioshi.dazel.game.util.DazelConstants;

public class DazelGameModePool extends GameModePool {

	private GameMode getMenu(Game game) {
		GameMode menuMode = new MenuMode(game);
		modePool.put(DazelConstants.MODE_MAIN_MENU, menuMode);
		return menuMode;
	}

	@Override
	protected GameMode initGameMode(Integer mode, Game game) {
		switch (mode) {
		case DazelConstants.MODE_MAIN_MENU:
			return getMenu(game);
		case DazelConstants.MODE_GAME_SCREEN:
			return getGameScreen(game);
		default:
			// TODO mettre une meilleure exception ici
			throw new RuntimeException();
		}

	}

	private GameMode getGameScreen(Game game) {
		GameMode gameScreenMode = new GameScreenMode(game);
		modePool.put(DazelConstants.MODE_GAME_SCREEN, gameScreenMode);
		return gameScreenMode;
	}

}
