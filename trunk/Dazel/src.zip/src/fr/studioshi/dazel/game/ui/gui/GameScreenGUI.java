package fr.studioshi.dazel.game.ui.gui;

import java.awt.Color;
import java.awt.Graphics;

import fr.studioshi.common.game.Game;
import fr.studioshi.common.game.ui.gui.GUI;
import fr.studioshi.dazel.game.util.DazelConstants;

public class GameScreenGUI extends GUI {

	public GameScreenGUI(Game game) {
		super(game);
	}

	public void render(Graphics graphics) {
		graphics.setColor(Color.white);
		graphics.fillRect(0, 0, DazelConstants.WINDOW_WIDTH,
				DazelConstants.WINDOW_HEIGHT);
	}

	public void process() {
		// TODO Auto-generated method stub

	}

}
