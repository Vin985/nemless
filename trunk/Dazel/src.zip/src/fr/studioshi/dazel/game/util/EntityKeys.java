package fr.studioshi.dazel.game.util;

public class EntityKeys {

	private EntityKeys(){
	}
	
	public static final String TRIFORCE_MENU = "TRIFORCE_MENU"; 
	
}
