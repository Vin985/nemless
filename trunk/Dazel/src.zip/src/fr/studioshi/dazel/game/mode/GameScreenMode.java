package fr.studioshi.dazel.game.mode;

import fr.studioshi.common.game.Game;
import fr.studioshi.common.game.mode.GameMode;
import fr.studioshi.common.game.ui.gui.GUIPool;
import fr.studioshi.dazel.game.ui.keylisteners.DazelKeyHandler;
import fr.studioshi.dazel.game.util.DazelConstants;

public class GameScreenMode extends GameMode {
	
	public GameScreenMode(Game game) {
		setGameMode(DazelConstants.MODE_GAME_SCREEN);
		setGui(GUIPool.getInstance().getGUI(DazelConstants.MODE_GAME_SCREEN,
				game));
		setKeyListener(new DazelKeyHandler());
	}
	
}
