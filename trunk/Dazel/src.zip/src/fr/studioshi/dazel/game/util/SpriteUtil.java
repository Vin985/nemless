package fr.studioshi.dazel.game.util;

public class SpriteUtil {

	private SpriteUtil() {
	}

	public final static String SPRITE_TRIFORCE_MENU = "items/triforce_menu";

}
