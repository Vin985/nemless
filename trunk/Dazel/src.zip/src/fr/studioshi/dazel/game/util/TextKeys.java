package fr.studioshi.dazel.game.util;

public class TextKeys {

	private TextKeys(){
	}

	
	
}
