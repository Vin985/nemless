package fr.studioshi.dazel.game.ui.gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import fr.studioshi.common.game.Game;
import fr.studioshi.common.game.elements.VisualElementCollection;
import fr.studioshi.common.game.model.Coordinates;
import fr.studioshi.common.game.ui.gui.GUI;
import fr.studioshi.common.game.ui.keylistener.Events;
import fr.studioshi.common.video.Text;
import fr.studioshi.dazel.game.elements.MenuCursor;
import fr.studioshi.dazel.game.util.DazelConstants;

public class MenuGUI extends GUI {

	private static final long serialVersionUID = 1857204049954442145L;

	private MenuCursor cursor;

	private VisualElementCollection<Text> texts;

	public MenuGUI(Game game) {
		super(game);

		cursor = new MenuCursor(new Coordinates(80, 110));
		texts = new VisualElementCollection<Text>();

		Text newGame = new Text("menu.newgame", new Coordinates(110, 120));
		Text exit = new Text("menu.exit", new Coordinates(110, 140));
		texts.add(newGame);
		texts.add(exit);
	}

	public void render(Graphics graphics) {
		graphics.setColor(Color.black);
		graphics.fillRect(0, 0, DazelConstants.WINDOW_WIDTH,
				DazelConstants.WINDOW_HEIGHT);
		graphics.setColor(Color.white);
		graphics.setFont(new Font("Arial", Font.BOLD, 15));

		cursor.render(graphics);
		texts.render(graphics);
	}

	public void process() {
		Events events = Events.getInstance();

		// Changement de mode
		if (events.isKeyEnterPressed()) {
			switch (cursor.getCursorPosition()) {
			case 0:
				game.setNewMode(DazelConstants.MODE_GAME_SCREEN);
				break;
			case 1 : 
				game.setRunning(false);
				break;
			default:
				break;// On ne fait rien
			}
		} else {
			// Mise a jour du curseur
			cursor.process();
		}

		// Remise a zero des evenements pour ce mode d'affichage
		events.reset();
	}

}
