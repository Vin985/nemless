package fr.studioshi.dazel.game.ui.gui;

import fr.studioshi.common.game.Game;
import fr.studioshi.common.game.ui.gui.GUI;
import fr.studioshi.common.game.ui.gui.GUIPool;
import fr.studioshi.dazel.game.util.DazelConstants;

public class DazelGUIPool extends GUIPool {

	@Override
	protected GUI initGui(Integer guiType, Game game) {
		switch (guiType) {
		case DazelConstants.MODE_MAIN_MENU:
			return getMenuGUI(game);
		case DazelConstants.MODE_GAME_SCREEN:
			return getGameScreenGUI(game);
		default:
			// TODO mettre une meilleure exception ici
			throw new RuntimeException();
		}
	}

	private GUI getGameScreenGUI(Game game) {
		GameScreenGUI gameScreenGUI = new GameScreenGUI(game);
		guiMap.put(DazelConstants.MODE_GAME_SCREEN, gameScreenGUI);
		return gameScreenGUI;
	}

	private GUI getMenuGUI(Game game) {
		MenuGUI menuGUI = new MenuGUI(game);
		guiMap.put(DazelConstants.MODE_MAIN_MENU, menuGUI);
		return menuGUI;
	}

}
