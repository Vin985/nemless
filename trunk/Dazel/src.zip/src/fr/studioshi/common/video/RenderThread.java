package fr.studioshi.common.video;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferStrategy;

import fr.studioshi.common.game.model.Coordinates;
import fr.studioshi.dazel.game.DazelGame;
import fr.studioshi.dazel.game.util.DazelConstants;

public class RenderThread extends Thread {

	private DazelGame game;

	/** The strategy that allows us to use accelerate page flipping */
	private BufferStrategy strategy;

	private Graphics2D graphics;

	public RenderThread(DazelGame game) {
		super();
		this.game = game;
		game.getGameWindow().createBufferStrategy(2);
		strategy = game.getGameWindow().getBufferStrategy();
		graphics = (Graphics2D) strategy.getDrawGraphics();
		graphics.setRenderingHint(RenderingHints.KEY_RENDERING,
				RenderingHints.VALUE_RENDER_QUALITY);
	}

	private boolean done_ = false;

	/**
	 * @return Returns the done_.
	 */
	public boolean isDone_() {
		return this.done_;
	}

	public void run() {
		int fps = 0;
		long fpsStartTime = System.currentTimeMillis();
		long loopStart;
		long loopDuration;
		Text fpsDisplay = new Text(fps + " fps", new Coordinates(20, 35));
		fpsDisplay.setFont(new Font("Arial", Font.BOLD, 15));

		while (game.isRunning()) {
			try {
				// trace loop start
				loopStart = System.currentTimeMillis();

				// check if we have been looping for more than 1 sec
				if (loopStart - fpsStartTime > 1000) {
					fpsDisplay.setText(fps + " fps");
					fpsStartTime = System.currentTimeMillis();
					fps = 0;
				}
				game.render(graphics);

				// display fps
				graphics.setColor(Color.YELLOW);
				fpsDisplay.render(graphics);

				// show graphics
				strategy.show();
				fps++;

				// trace duration of loop
				loopDuration = System.currentTimeMillis() - loopStart;

				// We aim for a speed of 50 fps. If loop has taken too long,
				// don't sleep. Else sleep just enough to limit screen rendering
				if (loopDuration < DazelConstants.RENDERING_SPEED) {
					Thread.sleep(DazelConstants.RENDERING_SPEED - loopDuration);
				} else {
					System.out.println("too slow");
				}
			} catch (InterruptedException ie) {
			}
		}
	}

	/**
	 * @param done_
	 *            The done_ to set.
	 */
	public void setDone_(boolean done_) {
		this.done_ = done_;
	}

}
