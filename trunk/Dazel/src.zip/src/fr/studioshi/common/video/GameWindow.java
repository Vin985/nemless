package fr.studioshi.common.video;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import fr.studioshi.common.game.ui.gui.GUI;
import fr.studioshi.common.game.ui.keylistener.KeyHandler;
import fr.studioshi.dazel.game.util.ConfKeys;
import fr.studioshi.dazel.game.util.ConfigurationLoader;
import fr.studioshi.dazel.game.util.DazelConstants;

public class GameWindow extends Frame {

	private static final long serialVersionUID = 7367414966572180602L;

	public GameWindow(GUI gui, KeyHandler keyListener) {
		super(ConfigurationLoader.getProperty(ConfKeys.DAZEL_VERSION));
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		pack();
		setSize(new Dimension(DazelConstants.WINDOW_WIDTH,
				DazelConstants.WINDOW_HEIGHT));
		setLocation(dim.width / 2 - getWidth() / 2, dim.height / 2
				- getHeight() / 2);
		addKeyListener(keyListener);
		setIgnoreRepaint(true);
		setVisible(true);
	}
	
	
}
