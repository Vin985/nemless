package fr.studioshi.common.video;

import java.awt.Graphics;

public interface GraphicElement {

	public void render(Graphics graphics);

}
