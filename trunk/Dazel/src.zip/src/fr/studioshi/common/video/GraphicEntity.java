package fr.studioshi.common.video;

import fr.studioshi.common.game.model.Coordinates;

public abstract class GraphicEntity implements GraphicElement {
	protected Coordinates coords;

	public GraphicEntity() {
	}

	public GraphicEntity(Coordinates coords) {
		super();
		this.coords = coords;
	}

	public Coordinates getCoords() {
		return coords;
	}

	public void setCoords(Coordinates coords) {
		this.coords = coords;
	}

}
