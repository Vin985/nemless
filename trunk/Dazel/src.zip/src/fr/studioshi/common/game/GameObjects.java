package fr.studioshi.common.game;

import fr.studioshi.common.video.GraphicElement;

public interface GameObjects extends GameElement, GraphicElement {

}
