package fr.studioshi.common.game.elements;

import java.awt.Graphics;
import java.util.List;

import fr.studioshi.common.video.GraphicElement;

public class VisualElementCollection<T extends GraphicElement> extends ElementCollection<T>  implements GraphicElement {

	public VisualElementCollection() {
		super();
	}

	public VisualElementCollection(List<T> list) {
		super(list);
	}

	public void render(Graphics graphics) {
		for (T visualElement : elements) {
			visualElement.render(graphics);
		}
	}

}
