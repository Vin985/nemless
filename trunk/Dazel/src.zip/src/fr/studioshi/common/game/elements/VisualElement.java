package fr.studioshi.common.game.elements;

import java.awt.Graphics;

import fr.studioshi.common.game.GameElement;
import fr.studioshi.common.game.model.Coordinates;
import fr.studioshi.common.video.GraphicElement;
import fr.studioshi.common.video.Sprite;

public abstract class VisualElement implements GraphicElement, GameElement {

	protected Sprite sprite;
	
	protected Coordinates coords;

	public VisualElement(Sprite sprite, Coordinates coords) {
		this.coords = coords;
		sprite.setCoords(this.coords);
		this.sprite = sprite;
	}

	public Sprite getSprite() {
		return sprite;
	}

	public void setSprite(Sprite sprite) {
		this.sprite = sprite;
	}
	
	public void render(Graphics graphics) {
		sprite.render(graphics);
	}

	public Coordinates getCoords() {
		return coords;
	}

	public void setCoords(Coordinates coords) {
		this.coords = coords;
	}
}
