package fr.studioshi.common.game.ui.gui;

import fr.studioshi.common.game.Game;
import fr.studioshi.common.game.GameElement;
import fr.studioshi.common.video.GraphicElement;

public abstract class GUI implements GraphicElement, GameElement {

	protected Game game;

	public GUI(Game game) {
		super();
		this.game = game;
	}

	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}

}
