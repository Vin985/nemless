package fr.studioshi.common.game;

import fr.studioshi.common.game.mode.GameMode;
import fr.studioshi.common.video.GameWindow;
import fr.studioshi.common.video.GraphicElement;

public abstract class Game implements GraphicElement, GameElement {

	protected int newMode;

	protected GameMode gameMode;

	protected GameWindow gameWindow;

	protected GameObjects gameObjects;

	protected boolean isRunning = true;

	public GameMode getGameMode() {
		return gameMode;
	}

	public GameObjects getGameObjects() {
		return gameObjects;
	}

	public GameWindow getGameWindow() {
		return gameWindow;
	}

	public int getNewMode() {
		return newMode;
	}

	public boolean isRunning() {
		return isRunning;
	}

	public void setGameMode(GameMode gameMode) {
		this.gameMode = gameMode;
	}

	public void setGameObjects(GameObjects gameObjects) {
		this.gameObjects = gameObjects;
	}

	public void setGameWindow(GameWindow gameWindow) {
		this.gameWindow = gameWindow;
	}

	public void setNewMode(int mode) {
		this.newMode = mode;
	}

	public void setRunning(boolean isRunning) {
		this.isRunning = isRunning;
	}
}
