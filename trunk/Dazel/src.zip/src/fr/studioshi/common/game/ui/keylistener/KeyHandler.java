package fr.studioshi.common.game.ui.keylistener;

import java.awt.event.KeyListener;


public abstract class KeyHandler implements KeyListener {

	protected Events events = Events.getInstance();
}
