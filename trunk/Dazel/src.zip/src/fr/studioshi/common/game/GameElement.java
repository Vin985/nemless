package fr.studioshi.common.game;

public interface GameElement {
	public void process();
}
