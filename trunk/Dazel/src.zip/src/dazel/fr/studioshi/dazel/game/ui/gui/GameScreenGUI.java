package fr.studioshi.dazel.game.ui.gui;

import fr.studioshi.common.game.Game;
import fr.studioshi.common.game.model.Coordinates;
import fr.studioshi.common.game.ui.gui.GUI;
import fr.studioshi.common.game.ui.keylistener.Events;
import fr.studioshi.dazel.game.elements.hero.Link;
import fr.studioshi.dazel.game.ui.gui.render.video.GameScreenGUI2DRender;
import fr.studioshi.dazel.game.util.DazelConstants;

public class GameScreenGUI extends GUI {

	private Link link;

	public GameScreenGUI(Game game) {
		super(game);
		visualRender = new GameScreenGUI2DRender(this);
		link = new Link(new Coordinates(100, 100));
	}

	public void process() {
		Events events = Events.getInstance();
		if (events.isKeyEscPressed()) {
			game.setNewMode(DazelConstants.MODE_MAIN_MENU);
		} else {
			link.process();
		}
		events.reset();
	}

	public Link getLink() {
		return link;
	}

	public void setLink(Link link) {
		this.link = link;
	}

}
