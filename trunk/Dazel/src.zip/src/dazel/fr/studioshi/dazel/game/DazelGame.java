package fr.studioshi.dazel.game;

import fr.studioshi.common.game.Game;
import fr.studioshi.common.game.mode.GameMode;
import fr.studioshi.common.game.mode.GameModePool;
import fr.studioshi.common.game.ui.gui.GUIPool;
import fr.studioshi.common.video.SpriteStore;
import fr.studioshi.dazel.game.mode.DazelGameModePool;
import fr.studioshi.dazel.game.ui.gui.DazelGUIPool;
import fr.studioshi.dazel.game.util.DazelConstants;
import fr.studioshi.dazel.game.video.DazelGameWindow;
import fr.studioshi.dazel.game.video.DazelSpriteLoader;

public class DazelGame extends Game {

	public DazelGame() {
		
		// Initialisation des stores
		SpriteStore.getInstance().init(new DazelSpriteLoader());
		
		// Initialisation des pools
		GUIPool.init(DazelGUIPool.class);
		GameModePool.init(DazelGameModePool.class);
		
		gameMode = GameModePool.getInstance().getMode(
				DazelConstants.MODE_MAIN_MENU, this);
		gameWindow = new DazelGameWindow(gameMode.getGui(), gameMode
				.getKeyListener());
	}

	public void process() {
		while (isRunning) {
			try {
				Thread.sleep(10);
				gameMode.process();
				if (newMode != DazelConstants.MODE_DEFAULT) {
					setGameMode(GameModePool.getInstance().getMode(newMode,
							this));
					newMode = DazelConstants.MODE_DEFAULT;
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		gameWindow.dispose();
	}

	public void setGameMode(GameMode gameMode) {
		gameWindow.removeKeyListener(this.gameMode.getKeyListener());
		this.gameMode = gameMode;
		gameWindow.addKeyListener(gameMode.getKeyListener());

	}

}
