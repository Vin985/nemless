package fr.studioshi.dazel.game.elements.render.video;

import fr.studioshi.common.game.model.Coordinates;
import fr.studioshi.common.game.model.SpriteRender;
import fr.studioshi.common.game.model.VisualRender;
import fr.studioshi.common.video.SpriteStore;
import fr.studioshi.dazel.game.util.EntityKeys;

public class MenuCursor2DRender extends VisualRender {

	public MenuCursor2DRender(Coordinates coords) {
		graphicElement = new SpriteRender(SpriteStore.getInstance().getSprite(
				EntityKeys.TRIFORCE_MENU), coords);
	}
}
