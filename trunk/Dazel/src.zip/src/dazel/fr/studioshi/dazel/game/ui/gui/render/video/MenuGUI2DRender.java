package fr.studioshi.dazel.game.ui.gui.render.video;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import fr.studioshi.common.game.model.VisualRender;
import fr.studioshi.dazel.game.ui.gui.MenuGUI;
import fr.studioshi.dazel.game.util.DazelConstants;

public class MenuGUI2DRender extends VisualRender {

	private MenuGUI gui;

	public MenuGUI2DRender(MenuGUI gui) {
		this.gui = gui;
	}

	@Override
	public void render(Graphics graphics) {
		graphics.setColor(Color.BLACK);
		graphics.fillRect(0, 0, DazelConstants.WINDOW_WIDTH,
				DazelConstants.WINDOW_HEIGHT);
		graphics.setColor(Color.WHITE);
		graphics.setFont(new Font("Arial", Font.BOLD, 15));

		gui.getCursor().render(graphics);
		gui.getTexts().render(graphics);
	}
}
