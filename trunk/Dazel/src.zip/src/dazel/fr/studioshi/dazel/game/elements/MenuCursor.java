package fr.studioshi.dazel.game.elements;

import fr.studioshi.common.game.model.Coordinates;
import fr.studioshi.common.game.model.GameObject;
import fr.studioshi.common.game.ui.keylistener.Events;
import fr.studioshi.dazel.game.elements.render.video.MenuCursor2DRender;
import fr.studioshi.dazel.game.util.DazelConstants;

public class MenuCursor extends GameObject {

	// deplacement du curseur en px
	private static final int CURSOR_MOVEMENT = 20;

	private int cursorPosition = 0;

	public MenuCursor(Coordinates coords) {
		this.visualRender = new MenuCursor2DRender(coords);
		this.coords = coords;
	}

	public void process() {
		Events events = Events.getInstance();

		if (events.isKeyDownPressed()
				&& cursorPosition + 1 < DazelConstants.MENU_OPTIONS_NUMBER) {
			coords.addY(CURSOR_MOVEMENT);
			cursorPosition++;
		} else if (events.isKeyUpPressed() && cursorPosition - 1 >= 0) {
			coords.addY(-CURSOR_MOVEMENT);
			cursorPosition--;
		}
	}

	public int getCursorPosition() {
		return cursorPosition;
	}

	public void setCursorPosition(int cursorPosition) {
		this.cursorPosition = cursorPosition;
	}

}
