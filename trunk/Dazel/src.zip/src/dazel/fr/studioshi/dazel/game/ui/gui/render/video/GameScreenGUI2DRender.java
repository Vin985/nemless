package fr.studioshi.dazel.game.ui.gui.render.video;

import java.awt.Color;
import java.awt.Graphics;

import fr.studioshi.common.game.model.VisualRender;
import fr.studioshi.dazel.game.ui.gui.GameScreenGUI;
import fr.studioshi.dazel.game.util.DazelConstants;

public class GameScreenGUI2DRender extends VisualRender {

	private GameScreenGUI gui;

	public GameScreenGUI2DRender(GameScreenGUI gui) {
		this.gui = gui;
	}

	@Override
	public void render(Graphics graphics) {
		graphics.setColor(Color.GRAY);
		graphics.fillRect(0, 0, DazelConstants.WINDOW_WIDTH,
				DazelConstants.WINDOW_HEIGHT);
		gui.getLink().render(graphics);
	}

}
