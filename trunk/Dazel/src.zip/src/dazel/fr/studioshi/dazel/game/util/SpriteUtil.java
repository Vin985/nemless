package fr.studioshi.dazel.game.util;

public class SpriteUtil {

	private SpriteUtil() {
	}

	public final static String SPRITE_TRIFORCE_MENU = "items/triforce_menu";
	public static final String SPRITE_LINK_TEST = "characters/link/link_move_left_green";

}
